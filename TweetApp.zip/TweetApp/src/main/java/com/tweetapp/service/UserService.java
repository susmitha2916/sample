package com.tweetapp.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import com.tweetapp.dao.UserDao;
import com.tweetapp.dao.UserDao;

public class UserService {
	public void insert() throws SQLException {
		UserDao.insertRecords();
		
	}
		}


