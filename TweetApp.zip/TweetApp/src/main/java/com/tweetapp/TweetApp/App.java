package com.tweetapp.TweetApp;

import java.sql.Connection;
import java.text.ParseException;
import java.util.Scanner;

import com.tweetapp.dao.UserDao;
import com.tweetapp.pages.UserLogin;
import com.tweetapp.pages.UserRegistration;
import com.tweetapp.service.UserService;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws Exception
    {
    	Scanner scan= new Scanner(System.in);
    	UserService service= new UserService();
    	Connection connection = UserDao.getConnection();
		if(connection != null)
			
			System.out.println("JDBC:connection is taken..");
        
		System.out.println( "Select Your Option!" );
        
        System.out.println("1.Register");
        System.out.println("2.Login");
        System.out.println("3.Forgot Password");
        
        String option=scan.nextLine();
        
        if(option.equals("1"))
        {
        	UserRegistration ur= new UserRegistration();
        	ur.register();
        	service.insert();
        	
        }
        if(option.equals("2")) {
        	
        	UserLogin ul= new UserLogin();
        	ul.login();
        	
        	
        }
      
        
    }
}

