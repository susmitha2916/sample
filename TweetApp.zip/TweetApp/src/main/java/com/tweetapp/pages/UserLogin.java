package com.tweetapp.pages;

import java.util.Scanner;

import com.tweetapp.model.UserModel;

public class UserLogin {
	
	Scanner scan  = new Scanner(System.in);
	UserModel ur = new UserModel();
	public void login() {
		System.out.println("Enter Username");
		String username=scan.nextLine();
		System.out.println("Enter Password");
		String pwd=scan.nextLine();
	}
	

}
