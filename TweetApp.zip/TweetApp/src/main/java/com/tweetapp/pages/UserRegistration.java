package com.tweetapp.pages;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Scanner;

import com.tweetapp.model.UserModel;

public class UserRegistration {
	
	Scanner scan= new Scanner(System.in);
	UserModel user =new UserModel();
    
    public   void register() throws ParseException
    {
    	System.out.println("Enter Your firstname Required");
    	String firstname =scan.nextLine();
		user.setFirstname(firstname);
    	System.out.println("Enter Your lastname Optional");
    	String lastname=scan.nextLine();
		user.setLastname(lastname);
		System.out.println("Enter your Dob");
		String d1=scan.nextLine();
		SimpleDateFormat format= new SimpleDateFormat("dd-MM-YYYY");
		Date date=format.parse(d1);
		user.setDob(date);
		System.out.println("Enter your Gender");
		String gender=scan.nextLine();
		user.setGender(gender);
		System.out.println("enter your Mail in someone@xyz.com format");
		String email=scan.nextLine();
		user.setGmail(email);
		System.out.println("Enter your Password");
		String pwd=scan.nextLine();
		user.setPassword(pwd);
		
		
    	
    	
    }
}
