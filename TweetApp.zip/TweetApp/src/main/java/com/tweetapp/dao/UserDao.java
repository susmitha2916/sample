package com.tweetapp.dao;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.sql.Date;
import java.util.Properties;
import com.tweetapp.pages.UserRegistration;

public class UserDao {
	UserRegistration ur= new UserRegistration();
	
	private static final String DB_DRIVER_CLASS="jdbc.driver";
	private static final String DB_USERNAME="jdbc.username";
	private static final String DB_PASSWORD="jdbc.password";
	private static final String DB_URL ="jdbc.url";
	
	private static Connection connection = null;
	private static Properties properties = null;
	static{
		try {
			properties = new Properties();
			properties.load(new FileInputStream("src/main/resources/db.properties"));
			Class.forName(properties.getProperty(DB_DRIVER_CLASS));
			connection = DriverManager.getConnection(properties.getProperty(DB_URL),properties.getProperty(DB_USERNAME) , properties.getProperty(DB_PASSWORD) );
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static   void insertRecords() throws SQLException {
		  System.out.println("Inserting records into the table...");
		  String sql = "insert into user(firstname, lastname,gender,dob,email,password) values(?,?,?,?,?,?)";
		  PreparedStatement statement = connection.prepareStatement(sql);
		// set param values
				  statement.setString(1, "ur.firstname");
		  statement.setString(2, "ur.lastname");
		  statement.setString(3, "ur.gender");
		  
		  statement.setObject( 4, "date" );
		  statement.setString(5, "ur.gmail");
		  statement.setString(6, "ur.password");
		  int rowsInserted = statement.executeUpdate();
		  if (rowsInserted > 0) {
		      System.out.println("A new user was inserted successfully!");
		  
		  }  
		  
	}  
		  
	public static Connection getConnection(){
		return connection;
	}
	
	
}
